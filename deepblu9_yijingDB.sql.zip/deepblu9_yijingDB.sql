-- phpMyAdmin SQL Dump
-- version 4.1.8
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Sam 21 Février 2015 à 08:36
-- Version du serveur :  5.5.41-37.0-log
-- Version de PHP :  5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `deepblu9_yijingDB`
--

-- --------------------------------------------------------

--
-- Structure de la table `batchops`
--

CREATE TABLE IF NOT EXISTS `batchops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchOperationName` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `branches`
--

CREATE TABLE IF NOT EXISTS `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=13 ;

--
-- Contenu de la table `branches`
--

INSERT INTO `branches` (`id`, `branche`) VALUES
(1, 'Xu'),
(2, 'Hai'),
(3, 'Zi'),
(4, 'Chou'),
(5, 'Yin'),
(6, 'Mao'),
(7, 'Chen'),
(8, 'Si'),
(9, 'Wu'),
(10, 'Wei'),
(11, 'Shen'),
(12, 'You');

-- --------------------------------------------------------

--
-- Structure de la table `cake_sessions`
--

CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `data` text COLLATE latin1_general_ci,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Contenu de la table `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES
('5f7fc03fgtjto3vtnf9915eh47', 'Config|a:3:{s:9:"userAgent";s:32:"f62ac97289f7541ae9480f79ebc39ed5";s:4:"time";i:1293587062;s:7:"timeout";i:10;}', 1293587062),
('suj4m7ljvlu7m0mo6u9ponp1j1', 'Config|a:3:{s:9:"userAgent";s:32:"c0963309fdf5e306d759df542232bae0";s:4:"time";i:1293658733;s:7:"timeout";i:10;}Message|a:0:{}', 1293658734),
('704dc8kfadm0f8mb891losk1a2', 'Config|a:3:{s:9:"userAgent";s:32:"c0963309fdf5e306d759df542232bae0";s:4:"time";i:1293655433;s:7:"timeout";i:10;}', 1293655440),
('vm2m1qkebrthk2um84nj7koo75', 'Config|a:3:{s:9:"userAgent";s:32:"c0963309fdf5e306d759df542232bae0";s:4:"time";i:1293666647;s:7:"timeout";i:10;}', 1293666647);

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hexagram_id` int(11) NOT NULL,
  `comment` text COLLATE latin1_general_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_hexagrams1` (`hexagram_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `comments`
--

INSERT INTO `comments` (`id`, `hexagram_id`, `comment`, `created`) VALUES
(1, 15, '<p>\r\n	Please nore than 1800 characters</p>\r\n', '2010-12-28 14:33:12'),
(2, 15, '<p>\r\n	Please nore than 1800 characters 2</p>\r\n', '2010-12-28 14:51:15');

-- --------------------------------------------------------

--
-- Structure de la table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `groupName` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `questionTemplate` varchar(360) COLLATE latin1_general_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `groups`
--

INSERT INTO `groups` (`id`, `parent_id`, `groupName`, `questionTemplate`, `created`) VALUES
(1, 0, 'Group1', '', '2010-12-22 07:02:26'),
(2, 0, 'Group2', '', '2010-12-22 07:02:36'),
(3, 2, 'Group23', '', '2010-12-22 07:02:46');

-- --------------------------------------------------------

--
-- Structure de la table `hexagrams`
--

CREATE TABLE IF NOT EXISTS `hexagrams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `refhexagram_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `efficaceUtilitaire` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `element` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `hexToHexParenthood` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `anneeTronc` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `anneeBranche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `moisTronc` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `moisBranche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `jourTronc` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `jourBranche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_hexagrams_questions1` (`question_id`),
  KEY `fk_hexagrams_refHexagrams1` (`refhexagram_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=18 ;

--
-- Contenu de la table `hexagrams`
--

INSERT INTO `hexagrams` (`id`, `question_id`, `refhexagram_id`, `parent_id`, `efficaceUtilitaire`, `element`, `created`, `hexToHexParenthood`, `anneeTronc`, `anneeBranche`, `moisTronc`, `moisBranche`, `jourTronc`, `jourBranche`) VALUES
(5, 5, 48, 0, 'wealth', 'wood', '2010-12-22 08:51:45', 'none', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(6, 5, 61, 5, 'wealth', 'earth', '2010-12-22 08:51:45', 'wealth', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(7, 5, 48, 0, 'wealth', 'wood', '2010-12-22 09:08:37', 'none', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(8, 5, 61, 7, 'wealth', 'earth', '2010-12-22 09:08:37', 'wealth', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(9, 5, 48, 0, 'wealth', 'wood', '2010-12-22 09:09:37', 'none', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(10, 5, 61, 9, 'wealth', 'earth', '2010-12-22 09:09:37', 'wealth', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(11, 5, 48, 0, 'wealth', 'wood', '2010-12-22 09:11:17', 'none', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(12, 5, 61, 11, 'wealth', 'earth', '2010-12-22 09:11:17', 'wealth', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(13, 5, 48, 0, 'wealth', 'wood', '2010-12-22 09:16:19', 'none', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(14, 5, 61, 13, 'wealth', 'earth', '2010-12-22 09:16:19', 'wealth', 'Bing', 'Yin', 'Whu', 'Chen', 'Whu', 'Zi'),
(15, 5, 56, 0, 'wealth', 'fire', '2010-12-22 09:33:37', 'none', 'Bing', 'Xu', 'JIA', 'Xu', 'JIA', 'Hai'),
(16, 5, 13, 15, 'wealth', 'fire', '2010-12-22 09:33:38', 'brother', 'Bing', 'Xu', 'JIA', 'Xu', 'JIA', 'Hai'),
(17, 5, 21, 0, 'wealth', 'wood', '2010-12-28 23:51:55', 'none', 'Yi', 'Hai', 'Ding', 'Chou', 'JIA', 'Chou');

-- --------------------------------------------------------

--
-- Structure de la table `loops`
--

CREATE TABLE IF NOT EXISTS `loops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `element` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `menucats`
--

CREATE TABLE IF NOT EXISTS `menucats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menucatField` varchar(150) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `menucats`
--

INSERT INTO `menucats` (`id`, `menucatField`) VALUES
(1, 'Questions'),
(2, 'Hexagrams');

-- --------------------------------------------------------

--
-- Structure de la table `menulinks`
--

CREATE TABLE IF NOT EXISTS `menulinks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menucat_id` int(11) NOT NULL,
  `title` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `controller` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `action` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `idparam` int(11) DEFAULT NULL,
  `optionsarray` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_menulinks_menucats1` (`menucat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `menulinks`
--

INSERT INTO `menulinks` (`id`, `menucat_id`, `title`, `url`, `controller`, `action`, `idparam`, `optionsarray`) VALUES
(1, 1, 'List Questions', '', 'Questions', 'index', NULL, ''),
(2, 2, 'List Hexagrams', '', 'Hexagrams', 'index', NULL, ''),
(3, 1, 'New Questions', '', 'Questions', 'add', NULL, '');

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `questionField` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `efficaceUtilitaire` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_questions_groups1` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Contenu de la table `questions`
--

INSERT INTO `questions` (`id`, `group_id`, `questionField`, `efficaceUtilitaire`) VALUES
(5, 1, 'Is that really a question 3 ?', 'wealth'),
(6, 1, 'Is that really a question ?', 'brother'),
(7, 3, 'Ahum, that''s the question', 'official'),
(8, 2, 'Is that really a question ?', 'wealth');

-- --------------------------------------------------------

--
-- Structure de la table `refhexagrams`
--

CREATE TABLE IF NOT EXISTS `refhexagrams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supTrigram` tinyint(4) NOT NULL,
  `infTrigram` tinyint(4) NOT NULL,
  `element` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `self` tinyint(4) NOT NULL,
  `other` tinyint(4) NOT NULL,
  `level1branch` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `level4branch` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=65 ;

--
-- Contenu de la table `refhexagrams`
--

INSERT INTO `refhexagrams` (`id`, `supTrigram`, `infTrigram`, `element`, `self`, `other`, `level1branch`, `level4branch`) VALUES
(1, 1, 1, 'metal', 6, 3, 'zi', 'wu'),
(2, 2, 2, 'earth', 6, 3, 'wei', 'chou'),
(3, 4, 7, 'water', 2, 5, 'zi', 'shen'),
(4, 8, 4, 'fire', 4, 1, 'yin', 'xu'),
(5, 4, 1, 'earth', 4, 1, 'zi', 'shen'),
(6, 1, 4, 'fire', 4, 1, 'yin', 'wu'),
(7, 2, 4, 'water', 3, 6, 'yin', 'chou'),
(8, 4, 2, 'earth', 3, 6, 'wei', 'shen'),
(9, 6, 1, 'wood', 1, 4, 'zi', 'wei'),
(10, 1, 5, 'earth', 5, 2, 'si', 'wu'),
(11, 2, 1, 'earth', 3, 6, 'zi', 'chou'),
(12, 1, 2, 'metal', 3, 6, 'wei', 'wu'),
(13, 1, 3, 'fire', 3, 6, 'mao', 'wu'),
(14, 3, 1, 'metal', 3, 6, 'zi', 'you'),
(15, 2, 8, 'metal', 5, 2, 'chen', 'chou'),
(16, 7, 2, 'wood', 1, 4, 'wei', 'wu'),
(17, 5, 7, 'wood', 3, 6, 'zi', 'hai'),
(18, 8, 6, 'wood', 3, 6, 'chen', 'xu'),
(19, 2, 5, 'earth', 2, 5, 'si', 'chou'),
(20, 6, 2, 'metal', 4, 1, 'wei', 'wei'),
(21, 3, 7, 'wood', 5, 2, 'zi', 'you'),
(22, 8, 3, 'earth', 1, 4, 'mao', 'xu'),
(23, 8, 2, 'metal', 5, 2, 'wei', 'xu'),
(24, 2, 7, 'earth', 1, 4, 'zi', 'chou'),
(25, 1, 7, 'wood', 4, 1, 'zi', 'wu'),
(26, 8, 1, 'earth', 2, 5, 'zi', 'xu'),
(27, 8, 7, 'wood', 4, 1, 'zi', 'xu'),
(28, 5, 6, 'wood', 4, 1, 'chen', 'hai'),
(29, 4, 4, 'water', 6, 3, 'yin', 'shen'),
(30, 3, 3, 'fire', 6, 3, 'mao', 'you'),
(31, 5, 8, 'metal', 3, 6, 'chen', 'hai'),
(32, 7, 6, 'wood', 3, 6, 'chen', 'wu'),
(33, 1, 8, 'metal', 2, 5, 'chen', 'wu'),
(34, 7, 1, 'earth', 4, 1, 'zi', 'wu'),
(35, 3, 2, 'metal', 4, 1, 'wei', 'you'),
(36, 2, 3, 'water', 4, 1, 'mao', 'chou'),
(37, 6, 3, 'wood', 2, 5, 'mao', 'wei'),
(38, 3, 5, 'earth', 4, 1, 'si', 'you'),
(39, 4, 8, 'metal', 4, 1, 'chen', 'shen'),
(40, 7, 4, 'wood', 2, 5, 'yin', 'wu'),
(41, 8, 5, 'earth', 3, 6, 'si', 'xu'),
(42, 6, 7, 'wood', 3, 6, 'zi', 'wei'),
(43, 5, 1, 'earth', 5, 2, 'zi', 'hai'),
(44, 1, 6, 'metal', 1, 4, 'chen', 'wu'),
(45, 5, 2, 'metal', 2, 5, 'wei', 'hai'),
(46, 2, 6, 'wood', 3, 6, 'chen', 'chou'),
(47, 5, 4, 'metal', 1, 4, 'yin', 'hai'),
(48, 4, 6, 'wood', 5, 2, 'chen', 'shen'),
(49, 5, 3, 'water', 4, 1, 'mao', 'hai'),
(50, 3, 6, 'fire', 2, 5, 'chen', 'you'),
(51, 7, 7, 'wood', 6, 3, 'zi', 'wu'),
(52, 8, 8, 'earth', 6, 3, 'chen', 'xu'),
(53, 6, 8, 'earth', 3, 6, 'chen', 'wei'),
(54, 7, 5, 'metal', 3, 6, 'si', 'wu'),
(55, 7, 3, 'water', 5, 2, 'mao', 'wu'),
(56, 3, 8, 'fire', 1, 4, 'chen', 'you'),
(57, 6, 6, 'wood', 6, 3, 'chen', 'wei'),
(58, 5, 5, 'metal', 6, 3, 'si', 'hai'),
(59, 6, 4, 'fire', 5, 2, 'yin', 'wei'),
(60, 4, 5, 'water', 1, 4, 'si', 'shen'),
(61, 6, 5, 'earth', 4, 1, 'si', 'wei'),
(62, 7, 8, 'metal', 4, 1, 'chen', 'wu'),
(63, 4, 3, 'water', 3, 6, 'mao', 'shen'),
(64, 3, 4, 'fire', 3, 6, 'yin', 'you');

-- --------------------------------------------------------

--
-- Structure de la table `relationships`
--

CREATE TABLE IF NOT EXISTS `relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hexagram_id` int(11) NOT NULL,
  `firstTrait` tinyint(4) NOT NULL,
  `secondTrait` tinyint(4) NOT NULL,
  `relationshipType` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `specialBranchStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_relationships_hexagrams1` (`hexagram_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=318 ;

--
-- Contenu de la table `relationships`
--

INSERT INTO `relationships` (`id`, `hexagram_id`, `firstTrait`, `secondTrait`, `relationshipType`, `specialBranchStatus`) VALUES
(219, 5, 1, 3, 'Affrontement', 0),
(220, 5, 1, 4, 'Affrontement', 0),
(221, 5, 1, 8, 'Blessure', 0),
(222, 5, 1, 12, 'Blessure', 0),
(223, 5, 2, 6, 'Affrontement', 2),
(224, 5, 2, 7, 'Soutien', 1),
(225, 5, 2, 11, 'Soutien', 1),
(226, 5, 3, 8, 'Soutien', 0),
(227, 5, 3, 12, 'Soutien', 0),
(228, 5, 4, 8, 'Soutien', 0),
(229, 5, 4, 12, 'Soutien', 0),
(230, 5, 5, 9, 'Soutien', 1),
(231, 5, 5, 10, 'Blessure', 1),
(232, 5, 6, 7, 'Blessure', 1),
(233, 5, 6, 11, 'Blessure', 1),
(234, 5, 9, 10, 'Affrontement', 2),
(235, 7, 1, 3, 'Affrontement', 0),
(236, 7, 1, 4, 'Affrontement', 0),
(237, 7, 1, 8, 'Blessure', 0),
(238, 7, 1, 12, 'Blessure', 0),
(239, 7, 2, 6, 'Affrontement', 2),
(240, 7, 2, 7, 'Soutien', 1),
(241, 7, 2, 11, 'Soutien', 1),
(242, 7, 3, 8, 'Soutien', 0),
(243, 7, 3, 12, 'Soutien', 0),
(244, 7, 4, 8, 'Soutien', 0),
(245, 7, 4, 12, 'Soutien', 0),
(246, 7, 5, 9, 'Soutien', 1),
(247, 7, 5, 10, 'Blessure', 1),
(248, 7, 6, 7, 'Blessure', 1),
(249, 7, 6, 11, 'Blessure', 1),
(250, 7, 9, 10, 'Affrontement', 2),
(251, 9, 1, 3, 'Affrontement', 0),
(252, 9, 1, 4, 'Affrontement', 0),
(253, 9, 1, 8, 'Blessure', 0),
(254, 9, 1, 12, 'Blessure', 0),
(255, 9, 2, 6, 'Affrontement', 2),
(256, 9, 2, 7, 'Soutien', 1),
(257, 9, 2, 11, 'Soutien', 1),
(258, 9, 3, 8, 'Soutien', 0),
(259, 9, 3, 12, 'Soutien', 0),
(260, 9, 4, 8, 'Soutien', 0),
(261, 9, 4, 12, 'Soutien', 0),
(262, 9, 5, 9, 'Soutien', 1),
(263, 9, 5, 10, 'Blessure', 1),
(264, 9, 6, 7, 'Blessure', 1),
(265, 9, 6, 11, 'Blessure', 1),
(266, 9, 9, 10, 'Affrontement', 2),
(267, 11, 1, 3, 'Affrontement', 0),
(268, 11, 1, 4, 'Affrontement', 0),
(269, 11, 1, 8, 'Blessure', 0),
(270, 11, 1, 12, 'Blessure', 0),
(271, 11, 2, 6, 'Affrontement', 2),
(272, 11, 2, 7, 'Soutien', 1),
(273, 11, 2, 11, 'Soutien', 1),
(274, 11, 3, 8, 'Soutien', 0),
(275, 11, 3, 12, 'Soutien', 0),
(276, 11, 4, 8, 'Soutien', 0),
(277, 11, 4, 12, 'Soutien', 0),
(278, 11, 5, 9, 'Soutien', 1),
(279, 11, 5, 10, 'Blessure', 1),
(280, 11, 6, 7, 'Blessure', 1),
(281, 11, 6, 11, 'Blessure', 1),
(282, 11, 9, 10, 'Affrontement', 2),
(283, 13, 1, 3, 'Affrontement', 0),
(284, 13, 1, 4, 'Affrontement', 0),
(285, 13, 1, 8, 'Blessure', 0),
(286, 13, 1, 12, 'Blessure', 0),
(287, 13, 2, 6, 'Affrontement', 2),
(288, 13, 2, 7, 'Soutien', 1),
(289, 13, 2, 11, 'Soutien', 1),
(290, 13, 3, 8, 'Soutien', 0),
(291, 13, 3, 12, 'Soutien', 0),
(292, 13, 4, 8, 'Soutien', 0),
(293, 13, 4, 12, 'Soutien', 0),
(294, 13, 5, 9, 'Soutien', 1),
(295, 13, 5, 10, 'Blessure', 1),
(296, 13, 6, 7, 'Blessure', 1),
(297, 13, 6, 11, 'Blessure', 1),
(298, 13, 9, 10, 'Affrontement', 2),
(299, 15, 1, 4, 'Soutien', 1),
(300, 15, 1, 8, 'Soutien', 1),
(301, 15, 2, 5, 'Soutien', 0),
(302, 15, 2, 9, 'Soutien', 0),
(303, 15, 2, 11, 'Affrontement', 0),
(304, 15, 3, 6, 'Soutien', 2),
(305, 15, 3, 7, 'Blessure', 1),
(306, 15, 3, 12, 'Affrontement', 1),
(307, 15, 5, 11, 'Blessure', 0),
(308, 15, 6, 7, 'Affrontement', 1),
(309, 15, 6, 10, 'Soutien', 2),
(310, 15, 6, 12, 'Blessure', 1),
(311, 15, 7, 10, 'Blessure', 1),
(312, 15, 7, 12, 'Soutien', 0),
(313, 15, 9, 11, 'Blessure', 0),
(314, 15, 10, 12, 'Affrontement', 1),
(315, 17, 1, 5, 'Blessure', 0),
(316, 17, 2, 6, 'Blessure', 1),
(317, 17, 3, 4, 'Soutien', 1);

-- --------------------------------------------------------

--
-- Structure de la table `traits`
--

CREATE TABLE IF NOT EXISTS `traits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hexagram_id` int(11) NOT NULL,
  `traitValue` tinyint(4) NOT NULL,
  `traitPosition` tinyint(4) NOT NULL,
  `isSelf` tinyint(1) NOT NULL,
  `isOther` tinyint(1) NOT NULL,
  `animal` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `branche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `element` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `parente` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `isEffUtil` tinyint(1) NOT NULL,
  `trouNoirJour` tinyint(1) NOT NULL,
  `trouNoirMois` tinyint(1) NOT NULL,
  `trouNoirAnnee` tinyint(1) NOT NULL,
  `isMaus` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_traits_hexagrams` (`hexagram_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=560 ;

--
-- Contenu de la table `traits`
--

INSERT INTO `traits` (`id`, `hexagram_id`, `traitValue`, `traitPosition`, `isSelf`, `isOther`, `animal`, `branche`, `element`, `parente`, `isEffUtil`, `trouNoirJour`, `trouNoirMois`, `trouNoirAnnee`, `isMaus`) VALUES
(482, 5, 6, 6, 0, 0, 'Red Bird', 'yin', 'wood', 'brother', 0, 0, 0, 0, 0),
(483, 5, 7, 5, 1, 0, 'Green Dragon', 'xu', 'earth', 'wealth', 1, 0, 1, 1, 0),
(484, 5, 8, 4, 0, 0, 'Black Turtle', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(485, 5, 9, 3, 0, 0, 'White Tiger', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(486, 5, 7, 2, 0, 1, 'Gray Serpent', 'wu', 'fire', 'child', 0, 1, 0, 0, 0),
(487, 5, 6, 1, 0, 0, 'Yellow Scorpion', 'chen', 'earth', 'wealth', 1, 0, 0, 0, 0),
(488, 6, 7, 6, 0, 0, 'Red Bird', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(489, 6, 7, 5, 0, 0, 'Green Dragon', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(490, 6, 8, 4, 1, 0, 'Black Turtle', 'wei', 'earth', 'wealth', 1, 1, 0, 0, 0),
(491, 6, 8, 3, 0, 0, 'White Tiger', 'chou', 'earth', 'wealth', 1, 0, 0, 0, 0),
(492, 6, 7, 2, 0, 0, 'Gray Serpent', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(493, 6, 7, 1, 0, 1, 'Yellow Scorpion', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(494, 7, 6, 6, 0, 0, 'Red Bird', 'yin', 'wood', 'brother', 0, 0, 0, 0, 0),
(495, 7, 7, 5, 1, 0, 'Green Dragon', 'xu', 'earth', 'wealth', 1, 0, 1, 1, 0),
(496, 7, 8, 4, 0, 0, 'Black Turtle', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(497, 7, 9, 3, 0, 0, 'White Tiger', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(498, 7, 7, 2, 0, 1, 'Gray Serpent', 'wu', 'fire', 'child', 0, 1, 0, 0, 0),
(499, 7, 6, 1, 0, 0, 'Yellow Scorpion', 'chen', 'earth', 'wealth', 1, 0, 0, 0, 0),
(500, 8, 7, 6, 0, 0, 'Red Bird', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(501, 8, 7, 5, 0, 0, 'Green Dragon', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(502, 8, 8, 4, 1, 0, 'Black Turtle', 'wei', 'earth', 'wealth', 1, 1, 0, 0, 0),
(503, 8, 8, 3, 0, 0, 'White Tiger', 'chou', 'earth', 'wealth', 1, 0, 0, 0, 0),
(504, 8, 7, 2, 0, 0, 'Gray Serpent', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(505, 8, 7, 1, 0, 1, 'Yellow Scorpion', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(506, 9, 6, 6, 0, 0, 'Red Bird', 'yin', 'wood', 'brother', 0, 0, 0, 0, 0),
(507, 9, 7, 5, 1, 0, 'Green Dragon', 'xu', 'earth', 'wealth', 1, 0, 1, 1, 0),
(508, 9, 8, 4, 0, 0, 'Black Turtle', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(509, 9, 9, 3, 0, 0, 'White Tiger', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(510, 9, 7, 2, 0, 1, 'Gray Serpent', 'wu', 'fire', 'child', 0, 1, 0, 0, 0),
(511, 9, 6, 1, 0, 0, 'Yellow Scorpion', 'chen', 'earth', 'wealth', 1, 0, 0, 0, 0),
(512, 10, 7, 6, 0, 0, 'Red Bird', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(513, 10, 7, 5, 0, 0, 'Green Dragon', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(514, 10, 8, 4, 1, 0, 'Black Turtle', 'wei', 'earth', 'wealth', 1, 1, 0, 0, 0),
(515, 10, 8, 3, 0, 0, 'White Tiger', 'chou', 'earth', 'wealth', 1, 0, 0, 0, 0),
(516, 10, 7, 2, 0, 0, 'Gray Serpent', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(517, 10, 7, 1, 0, 1, 'Yellow Scorpion', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(518, 11, 6, 6, 0, 0, 'Red Bird', 'yin', 'wood', 'brother', 0, 0, 0, 0, 0),
(519, 11, 7, 5, 1, 0, 'Green Dragon', 'xu', 'earth', 'wealth', 1, 0, 1, 1, 0),
(520, 11, 8, 4, 0, 0, 'Black Turtle', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(521, 11, 9, 3, 0, 0, 'White Tiger', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(522, 11, 7, 2, 0, 1, 'Gray Serpent', 'wu', 'fire', 'child', 0, 1, 0, 0, 0),
(523, 11, 6, 1, 0, 0, 'Yellow Scorpion', 'chen', 'earth', 'wealth', 1, 0, 0, 0, 0),
(524, 12, 7, 6, 0, 0, 'Red Bird', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(525, 12, 7, 5, 0, 0, 'Green Dragon', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(526, 12, 8, 4, 1, 0, 'Black Turtle', 'wei', 'earth', 'wealth', 1, 1, 0, 0, 0),
(527, 12, 8, 3, 0, 0, 'White Tiger', 'chou', 'earth', 'wealth', 1, 0, 0, 0, 0),
(528, 12, 7, 2, 0, 0, 'Gray Serpent', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(529, 12, 7, 1, 0, 1, 'Yellow Scorpion', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(530, 13, 6, 6, 0, 0, 'Red Bird', 'yin', 'wood', 'brother', 0, 0, 0, 0, 0),
(531, 13, 7, 5, 1, 0, 'Green Dragon', 'xu', 'earth', 'wealth', 1, 0, 1, 1, 0),
(532, 13, 8, 4, 0, 0, 'Black Turtle', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(533, 13, 9, 3, 0, 0, 'White Tiger', 'shen', 'metal', 'officiel', 0, 0, 0, 0, 0),
(534, 13, 7, 2, 0, 1, 'Gray Serpent', 'wu', 'fire', 'child', 0, 1, 0, 0, 0),
(535, 13, 6, 1, 0, 0, 'Yellow Scorpion', 'chen', 'earth', 'wealth', 1, 0, 0, 0, 0),
(536, 14, 7, 6, 0, 0, 'Red Bird', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(537, 14, 7, 5, 0, 0, 'Green Dragon', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(538, 14, 8, 4, 1, 0, 'Black Turtle', 'wei', 'earth', 'wealth', 1, 1, 0, 0, 0),
(539, 14, 8, 3, 0, 0, 'White Tiger', 'chou', 'earth', 'wealth', 1, 0, 0, 0, 0),
(540, 14, 7, 2, 0, 0, 'Gray Serpent', 'mao', 'wood', 'brother', 0, 0, 0, 0, 0),
(541, 14, 7, 1, 0, 1, 'Yellow Scorpion', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(542, 15, 7, 6, 0, 0, 'Black Turtle', 'si', 'fire', 'brother', 0, 0, 0, 0, 0),
(543, 15, 6, 5, 0, 0, 'White Tiger', 'wei', 'earth', 'child', 0, 0, 0, 1, 0),
(544, 15, 7, 4, 0, 1, 'Gray Serpent', 'you', 'metal', 'wealth', 1, 0, 1, 0, 0),
(545, 15, 7, 3, 0, 0, 'Yellow Scorpion', 'shen', 'metal', 'wealth', 1, 0, 1, 0, 0),
(546, 15, 8, 2, 0, 0, 'Red Bird', 'wu', 'fire', 'brother', 0, 0, 0, 1, 0),
(547, 15, 6, 1, 1, 0, 'Green Dragon', 'chen', 'earth', 'child', 0, 0, 0, 0, 0),
(548, 16, 7, 6, 0, 1, 'Black Turtle', 'xu', 'earth', 'child', 0, 0, 0, 0, 0),
(549, 16, 7, 5, 0, 0, 'White Tiger', 'shen', 'metal', 'wealth', 1, 0, 1, 0, 0),
(550, 16, 7, 4, 0, 0, 'Gray Serpent', 'wu', 'fire', 'brother', 0, 0, 0, 1, 0),
(551, 16, 7, 3, 1, 0, 'Yellow Scorpion', 'you', 'metal', 'wealth', 1, 0, 1, 0, 0),
(552, 16, 8, 2, 0, 0, 'Red Bird', 'chou', 'earth', 'child', 0, 0, 0, 0, 0),
(553, 16, 7, 1, 0, 0, 'Green Dragon', 'mao', 'wood', 'parent', 0, 0, 0, 0, 1),
(554, 17, 7, 6, 0, 0, 'Black Turtle', 'si', 'fire', 'child', 0, 0, 0, 0, 0),
(555, 17, 8, 5, 1, 0, 'White Tiger', 'wei', 'earth', 'wealth', 1, 0, 0, 0, 0),
(556, 17, 7, 4, 0, 0, 'Gray Serpent', 'you', 'metal', 'officiel', 0, 0, 1, 1, 0),
(557, 17, 8, 3, 0, 0, 'Yellow Scorpion', 'chen', 'earth', 'wealth', 1, 0, 0, 0, 0),
(558, 17, 8, 2, 0, 1, 'Red Bird', 'yin', 'wood', 'brother', 0, 0, 0, 0, 0),
(559, 17, 7, 1, 0, 0, 'Green Dragon', 'zi', 'water', 'parent', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `troncs`
--

CREATE TABLE IF NOT EXISTS `troncs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tronc` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=11 ;

--
-- Contenu de la table `troncs`
--

INSERT INTO `troncs` (`id`, `tronc`) VALUES
(1, 'JIA'),
(2, 'Yi'),
(3, 'Bing'),
(4, 'Ding'),
(5, 'Whu'),
(6, 'Ji'),
(7, 'Geng'),
(8, 'Xin'),
(9, 'Ren'),
(10, 'Gui');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `fk_comments_hexagrams1` FOREIGN KEY (`hexagram_id`) REFERENCES `hexagrams` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `hexagrams`
--
ALTER TABLE `hexagrams`
  ADD CONSTRAINT `fk_hexagrams_questions1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hexagrams_refHexagrams1` FOREIGN KEY (`refhexagram_id`) REFERENCES `refhexagrams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `menulinks`
--
ALTER TABLE `menulinks`
  ADD CONSTRAINT `fk_menulinks_menucats1` FOREIGN KEY (`menucat_id`) REFERENCES `menucats` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `fk_questions_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `relationships`
--
ALTER TABLE `relationships`
  ADD CONSTRAINT `fk_relationships_hexagrams1` FOREIGN KEY (`hexagram_id`) REFERENCES `hexagrams` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `traits`
--
ALTER TABLE `traits`
  ADD CONSTRAINT `fk_traits_hexagrams` FOREIGN KEY (`hexagram_id`) REFERENCES `hexagrams` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
