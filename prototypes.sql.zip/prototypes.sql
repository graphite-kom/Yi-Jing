-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Sam 21 Février 2015 à 12:20
-- Version du serveur: 5.5.8
-- Version de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `prototypes`
--

-- --------------------------------------------------------

--
-- Structure de la table `batchops`
--

CREATE TABLE IF NOT EXISTS `batchops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchOperationName` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `batchops`
--


-- --------------------------------------------------------

--
-- Structure de la table `batchvals`
--

CREATE TABLE IF NOT EXISTS `batchvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchop_id` int(11) NOT NULL,
  `field1` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `field2` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `field3` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `field4` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `field5` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_batch_values_batch_operations1` (`batchop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `batchvals`
--


-- --------------------------------------------------------

--
-- Structure de la table `branches`
--

CREATE TABLE IF NOT EXISTS `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=13 ;

--
-- Contenu de la table `branches`
--

INSERT INTO `branches` (`id`, `branche`) VALUES
(1, 'Zi'),
(2, 'Chou'),
(3, 'Yin'),
(4, 'Mao'),
(5, 'Chen'),
(6, 'Si'),
(7, 'Wu'),
(8, 'Wei'),
(9, 'Shen'),
(10, 'You'),
(11, 'Xu'),
(12, 'Hai');

-- --------------------------------------------------------

--
-- Structure de la table `cake_sessions`
--

CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `data` text COLLATE latin1_general_ci,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Contenu de la table `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES
('ad13qabihmvcb0sh4fjd8cgbk4', 'Config|a:3:{s:9:"userAgent";s:32:"c7d2d714346935ed7ff79d32c9a27b23";s:4:"time";i:1424521532;s:7:"timeout";i:10;}', 1424521532);

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hexagram_id` int(11) NOT NULL,
  `comment` text COLLATE latin1_general_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_hexagrams1` (`hexagram_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `comments`
--


-- --------------------------------------------------------

--
-- Structure de la table `descendantdatas`
--

CREATE TABLE IF NOT EXISTS `descendantdatas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mockdata_id` int(11) NOT NULL,
  `descendantdata1` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `descendantdata2` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `descendantdata3` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `descendantdata4` varchar(45) COLLATE latin1_general_ci NOT NULL COMMENT '		',
  `descendantdata5` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `descendantdata6` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `descendantdata7` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_descendantdatas_mockdatas1` (`mockdata_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `descendantdatas`
--


-- --------------------------------------------------------

--
-- Structure de la table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `groupName` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `questionTemplate` varchar(360) COLLATE latin1_general_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `groups`
--

INSERT INTO `groups` (`id`, `parent_id`, `groupName`, `questionTemplate`, `created`) VALUES
(1, 0, 'group1', '', '2011-10-03 17:27:11');

-- --------------------------------------------------------

--
-- Structure de la table `hexagrams`
--

CREATE TABLE IF NOT EXISTS `hexagrams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `refhexagram_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `efficaceUtilitaire` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `element` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `hexToHexParenthood` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `anneeTronc` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `anneeBranche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `moisTronc` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `moisBranche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `jourTronc` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `jourBranche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_hexagrams_questions1` (`question_id`),
  KEY `fk_hexagrams_refHexagrams1` (`refhexagram_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Contenu de la table `hexagrams`
--

INSERT INTO `hexagrams` (`id`, `question_id`, `refhexagram_id`, `parent_id`, `efficaceUtilitaire`, `element`, `created`, `hexToHexParenthood`, `anneeTronc`, `anneeBranche`, `moisTronc`, `moisBranche`, `jourTronc`, `jourBranche`) VALUES
(1, 1, 60, 0, 'wealth', 'water', '2011-10-10 16:28:33', 'none', 'Yi', 'Yin', 'Ding', 'Chen', 'Ji', 'Si'),
(2, 1, 20, 1, 'wealth', 'metal', '2011-10-10 16:28:33', 'parent', 'Yi', 'Yin', 'Ding', 'Chen', 'Ji', 'Si'),
(3, 3, 54, 0, 'child', 'metal', '2011-10-10 16:45:34', 'none', 'Bing', 'Si', 'Yi', 'Mao', 'Whu', 'Si'),
(4, 3, 12, 3, 'child', 'metal', '2011-10-10 16:45:34', 'brother', 'Bing', 'Si', 'Yi', 'Mao', 'Whu', 'Si');

-- --------------------------------------------------------

--
-- Structure de la table `loops`
--

CREATE TABLE IF NOT EXISTS `loops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `element` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `loops`
--


-- --------------------------------------------------------

--
-- Structure de la table `menucats`
--

CREATE TABLE IF NOT EXISTS `menucats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menucatField` varchar(150) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `menucats`
--


-- --------------------------------------------------------

--
-- Structure de la table `menulinks`
--

CREATE TABLE IF NOT EXISTS `menulinks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menucat_id` int(11) NOT NULL,
  `title` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `controller` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `action` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `idparam` int(11) DEFAULT NULL,
  `optionsarray` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_menulinks_menucats1` (`menucat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `menulinks`
--


-- --------------------------------------------------------

--
-- Structure de la table `mockdatas`
--

CREATE TABLE IF NOT EXISTS `mockdatas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mockdatafield1` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `mockdatafield2` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `mockdatafield3` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `mockdatafield4` varchar(45) COLLATE latin1_general_ci NOT NULL COMMENT '		',
  `mockdatafield5` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `mockdatafield6` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `mockdatafield7` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `mockdatas`
--


-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `questionField` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `efficaceUtilitaire` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `efficaceDescription` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_questions_groups1` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `questions`
--

INSERT INTO `questions` (`id`, `group_id`, `questionField`, `efficaceUtilitaire`, `efficaceDescription`) VALUES
(1, 1, 'This is a test question', 'wealth', 'wealth'),
(3, 1, 'another test question', 'child', '');

-- --------------------------------------------------------

--
-- Structure de la table `refhexagrams`
--

CREATE TABLE IF NOT EXISTS `refhexagrams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supTrigram` tinyint(4) NOT NULL,
  `infTrigram` tinyint(4) NOT NULL,
  `element` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `self` tinyint(4) NOT NULL,
  `other` tinyint(4) NOT NULL,
  `level1branch` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `level4branch` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=65 ;

--
-- Contenu de la table `refhexagrams`
--

INSERT INTO `refhexagrams` (`id`, `supTrigram`, `infTrigram`, `element`, `self`, `other`, `level1branch`, `level4branch`) VALUES
(1, 1, 1, 'metal', 6, 3, 'zi', 'wu'),
(2, 2, 2, 'earth', 6, 3, 'wei', 'chou'),
(3, 4, 7, 'water', 2, 5, 'zi', 'shen'),
(4, 8, 4, 'fire', 4, 1, 'yin', 'xu'),
(5, 4, 1, 'earth', 4, 1, 'zi', 'shen'),
(6, 1, 4, 'fire', 4, 1, 'yin', 'wu'),
(7, 2, 4, 'water', 3, 6, 'yin', 'chou'),
(8, 4, 2, 'earth', 3, 6, 'wei', 'shen'),
(9, 6, 1, 'wood', 1, 4, 'zi', 'wei'),
(10, 1, 5, 'earth', 5, 2, 'si', 'wu'),
(11, 2, 1, 'earth', 3, 6, 'zi', 'chou'),
(12, 1, 2, 'metal', 3, 6, 'wei', 'wu'),
(13, 1, 3, 'fire', 3, 6, 'mao', 'wu'),
(14, 3, 1, 'metal', 3, 6, 'zi', 'you'),
(15, 2, 8, 'metal', 5, 2, 'chen', 'chou'),
(16, 7, 2, 'wood', 1, 4, 'wei', 'wu'),
(17, 5, 7, 'wood', 3, 6, 'zi', 'hai'),
(18, 8, 6, 'wood', 3, 6, 'chen', 'xu'),
(19, 2, 5, 'earth', 2, 5, 'si', 'chou'),
(20, 6, 2, 'metal', 4, 1, 'wei', 'wei'),
(21, 3, 7, 'wood', 5, 2, 'zi', 'you'),
(22, 8, 3, 'earth', 1, 4, 'mao', 'xu'),
(23, 8, 2, 'metal', 5, 2, 'wei', 'xu'),
(24, 2, 7, 'earth', 1, 4, 'zi', 'chou'),
(25, 1, 7, 'wood', 4, 1, 'zi', 'wu'),
(26, 8, 1, 'earth', 2, 5, 'zi', 'xu'),
(27, 8, 7, 'wood', 4, 1, 'zi', 'xu'),
(28, 5, 6, 'wood', 4, 1, 'chen', 'hai'),
(29, 4, 4, 'water', 6, 3, 'yin', 'shen'),
(30, 3, 3, 'fire', 6, 3, 'mao', 'you'),
(31, 5, 8, 'metal', 3, 6, 'chen', 'hai'),
(32, 7, 6, 'wood', 3, 6, 'chen', 'wu'),
(33, 1, 8, 'metal', 2, 5, 'chen', 'wu'),
(34, 7, 1, 'earth', 4, 1, 'zi', 'wu'),
(35, 3, 2, 'metal', 4, 1, 'wei', 'you'),
(36, 2, 3, 'water', 4, 1, 'mao', 'chou'),
(37, 6, 3, 'wood', 2, 5, 'mao', 'wei'),
(38, 3, 5, 'earth', 4, 1, 'si', 'you'),
(39, 4, 8, 'metal', 4, 1, 'chen', 'shen'),
(40, 7, 4, 'wood', 2, 5, 'yin', 'wu'),
(41, 8, 5, 'earth', 3, 6, 'si', 'xu'),
(42, 6, 7, 'wood', 3, 6, 'zi', 'wei'),
(43, 5, 1, 'earth', 5, 2, 'zi', 'hai'),
(44, 1, 6, 'metal', 1, 4, 'chen', 'wu'),
(45, 5, 2, 'metal', 2, 5, 'wei', 'hai'),
(46, 2, 6, 'wood', 3, 6, 'chen', 'chou'),
(47, 5, 4, 'metal', 1, 4, 'yin', 'hai'),
(48, 4, 6, 'wood', 5, 2, 'chen', 'shen'),
(49, 5, 3, 'water', 4, 1, 'mao', 'hai'),
(50, 3, 6, 'fire', 2, 5, 'chen', 'you'),
(51, 7, 7, 'wood', 6, 3, 'zi', 'wu'),
(52, 8, 8, 'earth', 6, 3, 'chen', 'xu'),
(53, 6, 8, 'earth', 3, 6, 'chen', 'wei'),
(54, 7, 5, 'metal', 3, 6, 'si', 'wu'),
(55, 7, 3, 'water', 5, 2, 'mao', 'wu'),
(56, 3, 8, 'fire', 1, 4, 'chen', 'you'),
(57, 6, 6, 'wood', 6, 3, 'chen', 'wei'),
(58, 5, 5, 'metal', 6, 3, 'si', 'hai'),
(59, 6, 4, 'fire', 5, 2, 'yin', 'wei'),
(60, 4, 5, 'water', 1, 4, 'si', 'shen'),
(61, 6, 5, 'earth', 4, 1, 'si', 'wei'),
(62, 7, 8, 'metal', 4, 1, 'chen', 'wu'),
(63, 4, 3, 'water', 3, 6, 'mao', 'shen'),
(64, 3, 4, 'fire', 3, 6, 'yin', 'you');

-- --------------------------------------------------------

--
-- Structure de la table `relationships`
--

CREATE TABLE IF NOT EXISTS `relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hexagram_id` int(11) NOT NULL,
  `firstTrait` tinyint(4) NOT NULL,
  `secondTrait` tinyint(4) NOT NULL,
  `relationshipType` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `specialBranchStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_relationships_hexagrams1` (`hexagram_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=26 ;

--
-- Contenu de la table `relationships`
--

INSERT INTO `relationships` (`id`, `hexagram_id`, `firstTrait`, `secondTrait`, `relationshipType`, `specialBranchStatus`) VALUES
(1, 1, 1, 3, 'Affrontement', 0),
(2, 1, 1, 6, 'Blessure', 1),
(3, 1, 1, 8, 'Blessure', 1),
(4, 1, 1, 11, 'Blessure', 1),
(5, 1, 2, 5, 'Soutien', 0),
(6, 1, 2, 7, 'Soutien', 0),
(7, 1, 2, 10, 'Soutien', 0),
(8, 1, 3, 6, 'Soutien', 1),
(9, 1, 3, 8, 'Soutien', 1),
(10, 1, 3, 11, 'Soutien', 1),
(11, 1, 4, 9, 'Affrontement', 1),
(12, 1, 4, 12, 'Affrontement', 0),
(13, 3, 1, 5, 'Soutien', 0),
(14, 3, 1, 10, 'Soutien', 1),
(15, 3, 2, 6, 'Soutien', 0),
(16, 3, 2, 11, 'Soutien', 0),
(17, 3, 3, 4, 'Blessure', 1),
(18, 3, 3, 12, 'Soutien', 0),
(19, 3, 4, 9, 'Blessure', 1),
(20, 3, 4, 12, 'Affrontement', 1),
(21, 3, 5, 7, 'Soutien', 0),
(22, 3, 6, 8, 'Soutien', 0),
(23, 3, 7, 10, 'Soutien', 1),
(24, 3, 8, 11, 'Soutien', 0),
(25, 3, 9, 12, 'Soutien', 0);

-- --------------------------------------------------------

--
-- Structure de la table `traits`
--

CREATE TABLE IF NOT EXISTS `traits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hexagram_id` int(11) NOT NULL,
  `traitValue` tinyint(4) NOT NULL,
  `traitPosition` tinyint(4) NOT NULL,
  `isSelf` tinyint(1) NOT NULL,
  `isOther` tinyint(1) NOT NULL,
  `animal` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `branche` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `element` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `parente` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `isEffUtil` tinyint(1) NOT NULL,
  `trouNoirJour` tinyint(1) NOT NULL,
  `trouNoirMois` tinyint(1) NOT NULL,
  `trouNoirAnnee` tinyint(1) NOT NULL,
  `isMaus` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_traits_hexagrams` (`hexagram_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=25 ;

--
-- Contenu de la table `traits`
--

INSERT INTO `traits` (`id`, `hexagram_id`, `traitValue`, `traitPosition`, `isSelf`, `isOther`, `animal`, `branche`, `element`, `parente`, `isEffUtil`, `trouNoirJour`, `trouNoirMois`, `trouNoirAnnee`, `isMaus`) VALUES
(1, 1, 6, 6, 0, 0, 'Yellow Scorpion', 'yin', 'wood', 'child', 0, 0, 0, 0, 0),
(2, 1, 7, 5, 0, 0, 'Red Bird', 'xu', 'earth', 'officiel', 0, 1, 0, 0, 0),
(3, 1, 8, 4, 0, 1, 'Green Dragon', 'shen', 'metal', 'parent', 0, 0, 0, 0, 0),
(4, 1, 8, 3, 0, 0, 'Black Turtle', 'chou', 'earth', 'officiel', 0, 0, 0, 0, 0),
(5, 1, 9, 2, 0, 0, 'White Tiger', 'mao', 'wood', 'child', 0, 0, 0, 0, 0),
(6, 1, 9, 1, 1, 0, 'Gray Serpent', 'si', 'fire', 'wealth', 1, 0, 0, 0, 0),
(7, 2, 7, 6, 0, 0, 'Yellow Scorpion', 'mao', 'wood', 'child', 0, 0, 0, 0, 0),
(8, 2, 7, 5, 0, 0, 'Red Bird', 'si', 'fire', 'wealth', 1, 0, 0, 0, 0),
(9, 2, 8, 4, 1, 0, 'Green Dragon', 'wei', 'earth', 'officiel', 0, 0, 0, 0, 0),
(10, 2, 8, 3, 0, 0, 'Black Turtle', 'mao', 'wood', 'child', 0, 0, 0, 0, 0),
(11, 2, 8, 2, 0, 0, 'White Tiger', 'si', 'fire', 'wealth', 1, 0, 0, 0, 0),
(12, 2, 8, 1, 0, 1, 'Gray Serpent', 'wei', 'earth', 'officiel', 0, 0, 0, 0, 0),
(13, 3, 6, 6, 0, 1, 'Red Bird', 'xu', 'earth', 'parent', 0, 0, 0, 0, 0),
(14, 3, 6, 5, 0, 0, 'Green Dragon', 'shen', 'metal', 'brother', 0, 0, 0, 0, 0),
(15, 3, 7, 4, 0, 0, 'Black Turtle', 'wu', 'fire', 'officiel', 0, 0, 0, 0, 1),
(16, 3, 8, 3, 1, 0, 'White Tiger', 'chou', 'earth', 'parent', 0, 0, 1, 0, 0),
(17, 3, 9, 2, 0, 0, 'Gray Serpent', 'mao', 'wood', 'wealth', 0, 0, 0, 0, 0),
(18, 3, 9, 1, 0, 0, 'Yellow Scorpion', 'si', 'fire', 'officiel', 0, 0, 0, 0, 1),
(19, 4, 7, 6, 0, 1, 'Red Bird', 'xu', 'earth', 'parent', 0, 0, 0, 0, 0),
(20, 4, 7, 5, 0, 0, 'Green Dragon', 'shen', 'metal', 'brother', 0, 0, 0, 0, 0),
(21, 4, 7, 4, 0, 0, 'Black Turtle', 'wu', 'fire', 'officiel', 0, 0, 0, 0, 1),
(22, 4, 8, 3, 1, 0, 'White Tiger', 'mao', 'wood', 'wealth', 0, 0, 0, 0, 0),
(23, 4, 8, 2, 0, 0, 'Gray Serpent', 'si', 'fire', 'officiel', 0, 0, 0, 0, 1),
(24, 4, 8, 1, 0, 0, 'Yellow Scorpion', 'wei', 'earth', 'parent', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `troncs`
--

CREATE TABLE IF NOT EXISTS `troncs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tronc` varchar(45) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=11 ;

--
-- Contenu de la table `troncs`
--

INSERT INTO `troncs` (`id`, `tronc`) VALUES
(1, 'JIA'),
(2, 'Yi'),
(3, 'Bing'),
(4, 'Ding'),
(5, 'Whu'),
(6, 'Ji'),
(7, 'Geng'),
(8, 'Xin'),
(9, 'Ren'),
(10, 'Gui');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `batchvals`
--
ALTER TABLE `batchvals`
  ADD CONSTRAINT `fk_batch_values_batch_operations1` FOREIGN KEY (`batchop_id`) REFERENCES `batchops` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `fk_comments_hexagrams1` FOREIGN KEY (`hexagram_id`) REFERENCES `hexagrams` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `descendantdatas`
--
ALTER TABLE `descendantdatas`
  ADD CONSTRAINT `fk_descendantdatas_mockdatas1` FOREIGN KEY (`mockdata_id`) REFERENCES `mockdatas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `hexagrams`
--
ALTER TABLE `hexagrams`
  ADD CONSTRAINT `fk_hexagrams_questions1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hexagrams_refHexagrams1` FOREIGN KEY (`refhexagram_id`) REFERENCES `refhexagrams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `menulinks`
--
ALTER TABLE `menulinks`
  ADD CONSTRAINT `fk_menulinks_menucats1` FOREIGN KEY (`menucat_id`) REFERENCES `menucats` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `fk_questions_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `relationships`
--
ALTER TABLE `relationships`
  ADD CONSTRAINT `fk_relationships_hexagrams1` FOREIGN KEY (`hexagram_id`) REFERENCES `hexagrams` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `traits`
--
ALTER TABLE `traits`
  ADD CONSTRAINT `fk_traits_hexagrams` FOREIGN KEY (`hexagram_id`) REFERENCES `hexagrams` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
